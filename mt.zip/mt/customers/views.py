from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse, HttpResponseBadRequest, HttpResponseNotAllowed
from django.views.decorators.csrf import csrf_exempt, ensure_csrf_cookie
from .models import Customer
import json

@ensure_csrf_cookie
@csrf_exempt
def customer_list(request):
    if request.method == 'GET':
        customers = Customer.objects.all()
        return render(request, 'customers/customer_list.html', {'customers': customers})
    elif request.method == 'POST':
        try:
            data = json.loads(request.body)
            name = data.get('name')
            phone = data.get('phone')
        except ValueError:
            return HttpResponseBadRequest("Invalid JSON")

        if not all([name, phone]):
            return HttpResponseBadRequest("Missing required fields")

        customer = Customer.objects.create(name=name, phone=phone)
        return redirect('customer_list')

@csrf_exempt
def customer_detail(request, id):
    customer = get_object_or_404(Customer, id=id)
    if request.method == 'GET':
        return render(request, 'customers/customer_detail.html', {'customer': customer})
    else:
        return HttpResponseNotAllowed(['GET'])