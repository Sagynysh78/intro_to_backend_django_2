from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse, HttpResponseBadRequest, HttpResponseNotAllowed
from django.views.decorators.csrf import csrf_exempt, ensure_csrf_cookie
from .models import Reservation
from customers.models import Customer
from tables.models import Table
import json


@ensure_csrf_cookie
@csrf_exempt
def reservation_list(request):
    if request.method == 'GET':
        reservations = Reservation.objects.all()
        return render(request, 'reservations/reservation_list.html', {'reservations': reservations})
    elif request.method == 'POST':
        try:
            data = json.loads(request.body)
            customer_id = data.get('customer_id')
            table_id = data.get('table_id')
            date = data.get('date')
            status = data.get('status', 'pending')
        except ValueError:
            return HttpResponseBadRequest("Invalid JSON")

        if not all([customer_id, table_id, date]):
            return HttpResponseBadRequest("Missing required fields")

        # Check if the table is already reserved on that date
        if Reservation.objects.filter(table_id=table_id, date=date).exists():
            return HttpResponseBadRequest("Table already reserved on this date")

        # Check if the customer already has a reservation on that date
        if Reservation.objects.filter(customer_id=customer_id, date=date).exists():
            return HttpResponseBadRequest("Customer already has a reservation on this date")

        customer = get_object_or_404(Customer, id=customer_id)
        table = get_object_or_404(Table, id=table_id)
        Reservation.objects.create(customer=customer, table=table, date=date, status=status)
        return redirect('reservation_list')


@csrf_exempt
def reservation_detail(request, id):
    reservation = get_object_or_404(Reservation, id=id)
    if request.method == 'GET':
        return render(request, 'reservations/reservation_detail.html', {'reservation': reservation})
    elif request.method == 'POST':
        try:
            data = json.loads(request.body)
            status = data.get('status')
        except ValueError:
            return HttpResponseBadRequest("Invalid JSON")

        if not status:
            return HttpResponseBadRequest("Missing 'status' field")

        if status not in dict(Reservation.STATUS_CHOICES):
            return HttpResponseBadRequest("Invalid status")

        reservation.status = status
        reservation.save()
        return redirect('reservation_detail', id=id)
    elif request.method == 'DELETE':
        reservation.delete()
        return redirect('reservation_list')


def reservations_by_user(request, user_id):
    customer = get_object_or_404(Customer, id=user_id)
    reservations = Reservation.objects.filter(customer=customer)
    return render(request, 'reservations/reservations_by_user.html',
                  {'reservations': reservations, 'customer': customer})