from django.urls import path
from .views import reservation_list, reservation_detail, reservations_by_user

urlpatterns = [
    path('', reservation_list, name='reservation_list'),
    path('<int:id>/', reservation_detail, name='reservation_detail'),
    path('user/<int:user_id>/', reservations_by_user, name='reservations_by_user'),
]