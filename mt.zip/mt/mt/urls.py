from django.contrib import admin
from django.urls import path, include
from .views import redirect_to_customers

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', redirect_to_customers, name='home'),
    path('customers/', include('customers.urls')),
    path('tables/', include('tables.urls')),
    path('reservations/', include('reservations.urls')),
]