from django.shortcuts import redirect

def redirect_to_customers(request):
    return redirect('customer_list')