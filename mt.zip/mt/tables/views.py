from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse, HttpResponseBadRequest, HttpResponseNotAllowed
from django.views.decorators.csrf import csrf_exempt, ensure_csrf_cookie
from .models import Table
from reservations.models import Reservation
import json


@ensure_csrf_cookie
@csrf_exempt
def table_list(request):
    if request.method == 'GET':
        tables = Table.objects.all()
        return render(request, 'tables/table_list.html', {'tables': tables})
    elif request.method == 'POST':
        try:
            data = json.loads(request.body)
            number = data.get('number')
            seats = data.get('seats')
        except ValueError:
            return HttpResponseBadRequest("Invalid JSON")

        if not all([number, seats]):
            return HttpResponseBadRequest("Missing required fields")

        if Table.objects.filter(number=number).exists():
            return HttpResponseBadRequest("Table number already exists")

        Table.objects.create(number=number, seats=seats)
        return redirect('table_list')


@ensure_csrf_cookie
@csrf_exempt
def available_tables(request):
    if request.method != 'GET':
        return HttpResponseNotAllowed(['GET'])

    date = request.GET.get('date')
    time = request.GET.get('time')

    if not all([date, time]):
        return HttpResponseBadRequest("Missing required date and time")

    reservations = Reservation.objects.filter(date=date)
    reserved_table_ids = reservations.values_list('table_id', flat=True)
    available_tables = Table.objects.filter(is_available=True).exclude(id__in=reserved_table_ids)

    return render(request, 'tables/available_tables.html', {'tables': available_tables})